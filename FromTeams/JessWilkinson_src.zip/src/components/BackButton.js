import React from "react";
import { StyleSheet, TouchableOpacity, Text } from "react-native";
import { useNavigation } from "@react-navigation/native";


function BackButton({
    label = '< Back',
    buttonStyle = styles.backButton,
    textStyle = styles.buttonText,
})

{
    const navigation = useNavigation();

    const goBackHandler = () => {
        navigation.goBack();
    };

    return (
        <TouchableOpacity style={buttonStyle} onPress={goBackHandler}>
            <Text style={textStyle}>{label}</Text>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    buttonText:{
        color:'black',
        fontFamily:'poppins',
        fontSize: 16,
        fontWeight: 'medium',
    },
})

export default BackButton;