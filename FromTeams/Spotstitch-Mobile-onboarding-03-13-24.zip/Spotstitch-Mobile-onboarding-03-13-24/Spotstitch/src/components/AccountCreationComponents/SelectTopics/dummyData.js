export const dummyData = [
  {
    id: 1,
    name: 'Art',
    selected: false,
  },
  {
    id: 2,
    name: 'Business',
    selected: false,
  },
  {
    id: 3,
    name: 'Comedy',
    selected: false,
  },
  {
    id: 4,
    name: 'Education',
    selected: false,
  },
  {
    id: 5,
    name: 'Entertainment',
    selected: false,
  },
  {
    id: 6,
    name: 'Fashion',
    selected: false,
  },
  {
    id: 7,
    name: 'Fitness',
    selected: false,
  },
  {
    id: 8,
    name: 'Food',
    selected: false,
  },
  {
    id: 9,
    name: 'Gaming',
    selected: false,
  },
]
