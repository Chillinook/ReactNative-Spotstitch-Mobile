export const dummyData = [
  {
    id: 1,
    title: 'Basketball',
  },
  {
    id: 2,
    title: 'Classical Music',
  },
  {
    id: 3,
    title: 'Digital Art',
  },
  {
    id: 4,
    title: 'Food',
  },
  {
    id: 5,
    title: 'Dance',
  },
  {
    id: 6,
    title: 'Games',
  },
]
