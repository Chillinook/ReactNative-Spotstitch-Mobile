export const socialIconList = [
  {
    id: 1,
    name: 'facebook',
    onPress: () => {
      console.log('facebook')
    },
  },
  {
    id: 2,
    name: 'twitter',
    onPress: () => {
      console.log('twitter')
    },
  },
  {
    id: 3,
    name: 'instagram',
    onPress: () => {
      console.log('instagram')
    },
  },
  {
    id: 4,
    name: 'google',
    onPress: () => {
      console.log('google')
    },
  },
]
